#!/bin/sh

ifconfig $1 $2 netmask $3
